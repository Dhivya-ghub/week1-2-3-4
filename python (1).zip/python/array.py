from array import *
vals = array('i',[5,9,-8,4,2])
print(vals)
print(vals[2])

for i in range(5):
    print(vals[i])

#array values from using  input    
arr = array('i',[])
n=int(input("Enter the length of array"))
for i in range(n):
   x=int(input("enter the next value"))
   arr.append(x)
print(arr)   

#
y=int(input("Enter the value for search"))
k=0
for e in arr:
    if e==y:
        print(k)
        break
    k+=1
print(arr.index(y))

