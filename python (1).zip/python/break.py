#The break statement is used to terminate the loop or statement in which it is present
spam = 0
while spam < 5:
    spam = spam + 1
    if spam == 5:
       break;
    print('spam is  ' + str(spam))
