#Attributes->variable , Behaviour--> methods(function)
class computer:
    def _init_(self,cpu,ram):
        self.cpu = cpu
        self.ram = ram

       

     
    def config(self): #method
        print("config is", self.cpu,self.ram)
#com1 is object
com1 = computer(15,16)
com2 = computer('Ryen 3',8)

com1.config()