#The for loop in Python is an iterating function. If you have a sequence object like a list
print('my name is ')
for i in range (0, 10, 2):
    print("dhivya is five times  "  + str(i))