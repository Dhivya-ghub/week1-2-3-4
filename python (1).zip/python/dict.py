#Dictionaries are used to store data values in key:value pairs
#A dictionary is a collection which is ordered*, changeable and do not allow duplicates.
d={100:'dhivya',200:'Ravi',300:'ramesh'}  #d[key:value]
print(type(d))
e={}  # adding the item
e[400]='karthik'
d[100]='diya'
print(d)  # dupicate key not allowed but value old value eplace with new value
print(e)
x=d.get(200)
print(x)    #get method
y=d.keys()
print(y)   #display key value
d[300]='ram'  #change the value of a specific item by referring to its key name
print(d)
d.pop(300)    #The pop() method removes the item with the specified key name
print(d)
d.popitem()
print(d)  #The popitem() method removes the last inserted item 
thisdict =	{
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
for x, y in thisdict.items():
  print(x, y)        #Loop through both keys and values, by using the items() method

mydict = thisdict.copy()
print(mydict)    #Make a copy of a dictionary with the copy() method:
