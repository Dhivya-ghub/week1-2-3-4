suplies = ['pens','stablers,"binders','paper']
for i in range(len(suplies)) :
  print('index  ' + str(i)+ '  in suplies is   ' + suplies[i])

