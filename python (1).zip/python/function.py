def hello(name):
    print('Hello ' + name)
hello('Abi') 
hello('babu')   