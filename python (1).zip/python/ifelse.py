print('Enter a password')
password = input()
if password :
    print('Access granted')
else:
    print('wrong password')    