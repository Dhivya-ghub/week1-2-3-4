#Local variables are declared inside the function blocks 
#whereas Global variables are the type of variables that are declared outside every function of the program. 

x = 5 #global variable
y = 2

def sum():
    x = 10 # local variable
    y = 30
    z = x + y
    print(z)
    

sum()
a = x + y
print(a)