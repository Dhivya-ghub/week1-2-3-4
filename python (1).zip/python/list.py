#Lists are used to store multiple items in a single variable.
#List items are ordered, changeable, and allow duplicate values.
l = [10,'dhivya',20,30,40]
print(type(l))
print(l)
print(l[0])
print(l[-1])
print(l[1:4])
b = []
b.append(10) # append
b.append(20)
b.append(30)
print(b)
b.remove(30)  #remove
print(b)
b.insert(1,'dhivya') # insert
print(b)
print(b.index(20))  #index
s = [10,20,40,30]

