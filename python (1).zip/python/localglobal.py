a=10
a=20
def something():
    a=15
    print("in fun", a)

something()
print("outside fun", a)