# A class is a blueprint for declaring and creating objects. 
#Attributes->variable , Behaviour--> methods(function)
#using self we can access outside of the function  
# In Python the __init__() method is called the constructor and is always called when an object is created.
class computer:
    def __init__(self,cpu,ram):
        self.cpu = cpu
        self.ram = ram

       

     
    def config(self): #method
        print("config is", self.cpu, self.ram)
#Create an object of the class using the parameterized constructor
com1 = computer('15', 16)
com2 = computer('Ryen 3', 8)

com1.config()
com2.config()