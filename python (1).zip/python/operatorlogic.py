#Arithmetic operator
x=2 
y=3
z= x + y
print(z)
#Assignment operator
x=x+2
x+=2
print(x)
a,b=5,6
#unary operator
n=7
n=-n
print(n) 
#relational operator
print(a>b)
print(a<b)
#logic operator
print(a<8 and b<8)
print(a<8 and b>8)
print(a<8 or b>8)

