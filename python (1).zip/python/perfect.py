n = int(input("enter the number"))
sum=0
for i in range (1,n):
    if n%i == 0:
      sum=sum+i
if sum==n:
      print(sum, "is perfect number")
else:
      print(sum,"not a perfect number") 