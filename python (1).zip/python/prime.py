
num = int(input("Enter a number: "))
if num %  2 == 0:
    print( num," not prime")
    
else:
    print(" a prime")  