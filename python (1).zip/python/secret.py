import random
print("hello .what is your name? ")
name = input()
print('well, ' + 'I am thiking number between 1 to 20')
secretnumber = random.randint(1 , 20)
print('DEBUG: secret number is ' + str(secretnumber))
for guessTaken in range(1 , 7):
   print('take a guesss')
   guess = int(input())

   if guess < secretnumber:
      print("your guess is too low")
   elif guess > secretnumber:
      print('your guesss is too high')
   else:
      break
if guess == secretnumber:
    print('good job,' + name +' ! your gueesed number in' + str(guessTaken) + 'guesss')
else:
   print('Nope the numbe i was thinking was ' + str(guessTaken))