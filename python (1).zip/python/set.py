# Note: the set list is unordered, meaning: the items will appear in a random order.
#order is not required,duplicate are not allowed
thisset = {"apple", "banana","cherry" ,"cherry"}
print(type(thisset))
print(thisset)
thisset.add("mango")
print(thisset)
thisset.remove("apple")
print(thisset)

