import sys
print('Hello')
sys.exit()
print('goodbye')