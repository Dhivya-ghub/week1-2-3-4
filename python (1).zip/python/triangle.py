for i in range (0,6):  #rows 
    for j in range(i+1):  # colums
      
      print("*",end="") 
    print(" ")
    

  