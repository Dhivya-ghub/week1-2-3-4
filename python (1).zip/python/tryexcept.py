#The try block lets you test a block of code for errors. The except block lets you handle the error.
try:
    #value = 10 / 0
    number = int(input('Enter anmber: '))
    print(number)

except ZeroDivisionError:
     print('Divided by zero')
except ValueError:
     print('Invalid input')