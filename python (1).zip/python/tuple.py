# Tuples are used to store multiple items in a single variable
#A tuple is a collection which is ordered and unchangeable.t
k=()
print(type(k))
t=(10)  
print(type(t))  #its taking int
thistuple = ("apple","cherry", "banana", "cherry")
print(thistuple)  #tuples allow duplicate values
print(thistuple[1]) # access tuple
i = 0
while i < len(thistuple):
  print(thistuple[i])
  i = i + 1   # loop in tuple

mytuble=thistuple * 2
print(mytuble)   #If you want to multiply the content of a tuple a given number of times, you can use the * operator:

x = thistuple.count('cherry')

print(x)  #The count() method returns the number of times a specified value appears in the tuple.

