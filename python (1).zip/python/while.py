#  while loop we can execute a set of statements as long as a condition is true.
name = ' '
while name != 'dhivya' :
    print('Plesase tye your name')
    name = input()
print('thank you')